import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

// final Color textwhite = HexColor('#1C1F2E');
final Color textblack = HexColor('#1C1F2E');
final Color borderGrey = HexColor('#BFC3C8');
final Color backgroundWhite = HexColor('#FAFAFA');
final Color borderPinkDark = HexColor('#FFCDD8');
final Color buttonRed = HexColor('#FF033E');
//backgroundblack
//1C1F2E
//FAFAFA
//BFC3C8