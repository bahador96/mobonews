import 'package:flutter/material.dart';
import 'package:news/constants.dart';
import 'package:scroll_snap_list/scroll_snap_list.dart';

class HomeSceen extends StatefulWidget {
  const HomeSceen({Key? key}) : super(key: key);

  @override
  State<HomeSceen> createState() => _HomeSceenState();
}

class _HomeSceenState extends State<HomeSceen>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundWhite,
      body: Column(
        children: [
          SizedBox(
            height: 12,
          ),
          _getAppBar(),
          _getTabBar(),
          _getHeaderPostNews(),
          SizedBox(
            height: 15,
          ),
          Directionality(
            textDirection: TextDirection.rtl,
            child: Container(
              height: 294,
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(20),
              ),
              child: ScrollSnapList(
                  itemBuilder: _buildListItem,
                  itemCount: 10,
                  itemSize: 380,
                  onItemFocus: (index) {}),
            ),
          ),
          SizedBox(
            height: 15,
          ),
          _getFavoriteNews(),
          SizedBox(
            height: 0,
          ),
          _buildVerticalListItem(),
        ],
      ),
    );
  }

  Widget _getFavoriteNews() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 1),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Container(
          child: Row(
            children: [
              Text(
                'خبر هایی که علاقه داری',
                style: TextStyle(
                  fontSize: 17,
                  fontFamily: 'SB',
                  fontWeight: FontWeight.w700,
                  color: textblack,
                ),
              ),
              Spacer(),
              Text(
                'مشاهده بیشتر',
                style: TextStyle(
                  fontSize: 17,
                  fontFamily: 'SB',
                  color: textblack,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _getHeaderPostNews() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        child: Row(
          children: [
            Text(
              'مشاهده های بیشتر',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'SB',
                fontWeight: FontWeight.w700,
                color: textblack,
              ),
            ),
            Spacer(),
            Text(
              ' خبر های دذاغ',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'SB',
                color: textblack,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _getTabBar() {
    return Container(
      width: 380,
      height: 43,
      margin: EdgeInsets.symmetric(horizontal: 24, vertical: 32),
      decoration: BoxDecoration(
          color: backgroundWhite, borderRadius: BorderRadius.circular(21.5)),
      child: TabBar(
        controller: _tabController,
        labelStyle: TextStyle(
          fontSize: 16,
          fontFamily: 'SB',
          color: textblack,
        ),
        unselectedLabelStyle: TextStyle(
            color: borderGrey,
            fontFamily: 'SB',
            fontSize: 17,
            fontWeight: FontWeight.w700),
        unselectedLabelColor: textblack,
        indicator: BoxDecoration(
          color: textblack,
          // color: Colors.red,
          borderRadius: BorderRadius.circular(21.5),
        ),
        labelColor: borderGrey,
        tabs: [
          Tab(
            text: 'دنبال کنید',
          ),
          Tab(
            text: 'پشنهادی',
          ),
        ],
      ),
    );
  }

  Widget _getAppBar() {
    return AppBar(
      backgroundColor: backgroundWhite,
      elevation: 0,
      leading: Image.asset(
        'images/notification_status.png',
        color: textblack,
      ),
      centerTitle: true,
      title: Container(
        child: ClipRRect(
          child: Image.asset(
            'images/logo.png',
            fit: BoxFit.cover,
            color: textblack,
          ),
        ),
      ),
    );
  }

  Widget _buildListItem(BuildContext context, int index) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: EdgeInsets.only(right: 5, left: 5),
        child: Container(
          margin: EdgeInsets.only(top: 2),
          width: 279,
          height: 294,
          decoration: BoxDecoration(
            color: borderGrey,
            borderRadius: BorderRadius.circular(21.5),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(21.5),
            child: Column(
              children: [
                Stack(
                  alignment: Alignment.topRight,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.asset(
                        "images/news_hot_01.png",
                        fit: BoxFit.cover,
                      ),
                    ),
                    Positioned(
                      right: 10,
                      top: 10,
                      child: Container(
                        width: 58,
                        height: 28,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: buttonRed.withOpacity(0.5),
                        ),
                        child: Center(
                          child: Text(
                            'ورزشی',
                            style: TextStyle(
                              fontFamily: 'SB',
                              fontSize: 10,
                              color: borderGrey,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Image.asset(
                        'images/news_agency02.png',
                        width: 20,
                        height: 20,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        'پیشنهاد مونیوز',
                        style: TextStyle(
                          color: textblack,
                          fontSize: 12,
                          fontFamily: 'SB',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Spacer(),
                      Text(
                        '5 دقیقه قبل',
                        style: TextStyle(
                          color: textblack,
                          fontSize: 12,
                          fontFamily: 'SB',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 10, left: 5),
                  child: Text(
                    'پاسخ منفی پورتو به چلسی برای جذب طارمی با طعم تهدید!',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      color: textblack,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                SizedBox(height: 12),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Image.asset(
                        'images/news_agency01.png',
                        width: 20,
                        height: 20,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        'خبر گذاری آخرین خبر',
                        style: TextStyle(
                          color: textblack,
                          fontSize: 12,
                          fontFamily: 'SB',
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Spacer(),
                      Image.asset(
                        'images/short_Menu.png',
                        color: textblack,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildVerticalListItem() {
    return Expanded(
      child: Container(
        child: ListView.builder(
          itemCount: 5,
          itemBuilder: (context, index) {
            return Directionality(
              textDirection: TextDirection.rtl,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                child: Container(
                  width: 380,
                  height: 142,
                  decoration: BoxDecoration(
                    color: borderGrey,
                    borderRadius: BorderRadius.circular(21.5),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(21.5),
                    child: Row(
                      children: [
                        Stack(
                          alignment: Alignment.topRight,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Image.asset(
                                  "images/news_interest.png",
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Positioned(
                              right: 15,
                              top: 15,
                              child: Container(
                                width: 58,
                                height: 28,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  color: buttonRed.withOpacity(0.5),
                                ),
                                child: Center(
                                  child: Text(
                                    'تکنولوژی',
                                    style: TextStyle(
                                      fontFamily: 'SB',
                                      fontSize: 10,
                                      color: borderGrey,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: 5),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                '''سـاعـت هوشـمـنـد گــارمـیـن Venu Sq 2 
     عمر باتری ۱۱ روزه معرفی شد''',
                                style: TextStyle(
                                  color: textblack,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w900,
                                ),
                                // textAlign: TextAlign.right,
                              ),
                              Text(
                                ''' گارمین در رویداد IFA ۲۰۲۲ ساعت هوشمند Venu Sq 2 و ردیاب سلامت 
    کودکان موسوم به Black Panther Vivofit Jr 3 را معرفی کرد.''',
                                style: TextStyle(
                                  fontSize: 8,
                                  color: buttonRed,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'SM',
                                ),
                                // textAlign: TextAlign.right,
                              ),
                              SizedBox(
                                height: 12,
                              ),
                              Expanded(
                                child: Row(
                                  children: [
                                    Image.asset(
                                      'images/news_agency02.png',
                                      width: 20,
                                      height: 20,
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'خبر گذاری زومیت',
                                      style: TextStyle(
                                        color: textblack,
                                        fontSize: 12,
                                        fontFamily: 'SB',
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 110,
                                    ),
                                    // Spacer(),
                                    Image.asset(
                                      'images/short_Menu.png',
                                      color: textblack,
                                      fit: BoxFit.cover,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _getContentPostNewsInterested() {
    return Container(
      width: 380,
      height: 142,
      margin: EdgeInsets.symmetric(horizontal: 24),
      decoration: BoxDecoration(
          color: backgroundWhite, borderRadius: BorderRadius.circular(20)),
      child: Row(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 8, right: 8, bottom: 8),
            child: Stack(
              children: [
                Container(
                  height: 116,
                  width: 116,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      "assets/images/news_interest.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Positioned(
                  right: 10,
                  top: 10,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: buttonRed.withOpacity(0.5),
                    ),
                    width: 58,
                    height: 28,
                    child: Center(
                      child: Text(
                        "تکنولوژی",
                        style: TextStyle(
                            fontFamily: 'SB',
                            fontSize: 10,
                            color: backgroundWhite),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Text(
                    "سـاعـت هوشـمـنـد گــارمـیـن Venu Sq 2 بـا عمر باتری ۱۱ روزه معرفی شد",
                    style: TextStyle(
                      color: textblack,
                      fontFamily: 'SB',
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    "گارمین در رویداد IFA ۲۰۲۲ ساعت هوشمند Venu Sq 2 و ردیاب سلامت کودکان موسوم به Black Panther Vivofit Jr 3 را معرفی کرد.",
                    style: TextStyle(
                      color: borderGrey,
                      fontFamily: 'SM',
                      fontSize: 8,
                    ),
                  ),
                  SizedBox(height: 10),
                  Expanded(
                    child: Row(
                      children: [
                        Image.asset(
                          'assets/images/news_agency02.png',
                          width: 16,
                          height: 16,
                        ),
                        SizedBox(width: 5),
                        Text(
                          "خبرگزاری زومیت",
                          style: TextStyle(
                            color: textblack,
                            fontFamily: 'SS',
                            fontSize: 8,
                          ),
                        ),
                        Spacer(),
                        Image.asset(
                          'assets/images/short_Menu.png',
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
